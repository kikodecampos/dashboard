<footer class="main-footer">
      <strong>Copyright &copy; 2014-<?php echo date('Y')?> <a target="_blank" href="https://adminlte.io">Servac</a>.</strong>
      Todos os direitos reservados.
      <div class="float-right d-none d-sm-inline-block">
        <b>Version</b> 3.2.0
      </div>
    </footer>